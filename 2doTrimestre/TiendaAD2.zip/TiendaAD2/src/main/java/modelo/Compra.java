package modelo;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Entity
@Table (name="compras")
public class Compra {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idcompras")
	private int idcompras;
	
	@Column(name = "fecha")
	private Date fecha;
	
	@Column(name = "unidades")
	private int unidades;
	
	@ManyToOne
	@JoinColumn(name = "id_producto", nullable = false)
	private Producto producto;
	
	public Compra() {
		
	}

	public Compra(Date fecha, Producto producto, int unidades) {
		super();
		this.fecha = fecha;
		this.producto = producto;
		this.unidades = unidades;
	}

	public int getIdcompras() {
		return idcompras;
	}

	public void setIdcompras(int idcompras) {
		this.idcompras = idcompras;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public int getUnidades() {
		return unidades;
	}

	public void setUnidades(int unidades) {
		this.unidades = unidades;
	
	}

	@Override
	public String toString() {
		return "Compra [idcompras=" + idcompras + ", fecha=" + fecha + ", unidades=" + unidades + ", producto="
				+ producto + "]";
	}

	
}
	
	
	
	
