package modelo;

import java.sql.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.context.internal.ThreadLocalSessionContext;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Main {

	public static void main(String[] args) {

// Configurar la sesin de Hibernate
		SessionFactory sessionFactory = new Configuration().configure()
//llama al fichero hibernate.cfg.xml

				//.configure("hibernate.cfg.xml") // Ruta del archivo de configuracin de Hibernate
				.buildSessionFactory(); // Construir la sesin de Hibernate

// Configurar la sesin en el contexto actual
		ThreadLocalSessionContext context = new ThreadLocalSessionContext((SessionFactoryImplementor) sessionFactory);
		context.bind(sessionFactory.openSession());

		try {
// Crear objeto fabricante
			Fabricante fabricante = new Fabricante("PC Componentes");
			// Obtener la sesión actual
			Session session = context.currentSession();
			// Iniciar transacción (ejecución de sentencia de bd)
			session.beginTransaction();
			// Guardar objeto fabricante en la base de datos
			session.save(fabricante);
			// Hacer commit de la transacción
			session.getTransaction().commit();
			// Crear objeto producto
			// Crear objeto producto
			Producto pc1 = new Producto("Portátil estudiar",1000.00f, fabricante);
			// Obtener la sesión actual
			Session session1 = context.currentSession();
			// Iniciar transacción
			session1.beginTransaction();
			// Guardar objeto producto en la base de datos
			session1.save(pc1);
			// Hacer commit de la transacción
			session1.getTransaction().commit();
			
			Compra compra = new Compra(Date.valueOf("2023-01-19"), pc1 , 2);
			Session session2 = context.currentSession();
			session2.beginTransaction();
			session2.save(compra);
			session2.getTransaction().commit();
			System.out.println(pc1.toString());
			System.out.println(fabricante.toString());
			System.out.println(compra.toString());

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
// Desligar la sesión del contexto
			ThreadLocalSessionContext.unbind(sessionFactory);
// Cerrar la sesión de Hibernate
			sessionFactory.close();
		}
	}
}