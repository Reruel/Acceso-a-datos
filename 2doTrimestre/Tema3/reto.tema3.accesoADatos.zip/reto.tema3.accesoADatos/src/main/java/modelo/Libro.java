package modelo;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table (name="libro")
public class Libro {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="id")
	private int id;
	
	@Column(name ="titulo")
	private String titulo;

	@Column(name ="precio")
	private double precio;
	
	@Column(name ="editorial")
	private String editorial;
	
	@Column(name ="fecha_publicacion")
	private Date fecha_publicacion;
	
	@OneToMany(mappedBy = "libro", cascade = CascadeType.ALL)
	private List<Libro_Autor> autores = new ArrayList<>();
	
	@OneToMany(mappedBy = "libro", cascade = CascadeType.ALL)
	private List<Libro_Categoria> categorias = new ArrayList<>();
	
	@OneToMany(mappedBy = "libro", cascade = CascadeType.ALL)
	private List<Libro_Pedido> pedidos = new ArrayList<>();
	
	
	public List<Libro_Autor> getAutores() {
		return autores;
	}

	public void setAutores(List<Libro_Autor> autores) {
		this.autores = autores;
	}

	public List<Libro_Categoria> getCategorias() {
		return categorias;
	}

	public void setCategorias(List<Libro_Categoria> categorias) {
		this.categorias = categorias;
	}

	public List<Libro_Pedido> getPedidos() {
		return pedidos;
	}

	public void setPedidos(List<Libro_Pedido> pedidos) {
		this.pedidos = pedidos;
	}

	public Libro() {
		super();
	}

	public Libro(String titulo, double precio,String editorial, Date fecha_publicacion) {
		super();
		this.titulo = titulo;
		this.precio = precio;
		this.editorial = editorial;
		this.fecha_publicacion = fecha_publicacion;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public Date getFecha_publicacion() {
		return fecha_publicacion;
	}

	public void setFecha_publicacion(Date fecha_publicacion) {
		this.fecha_publicacion = fecha_publicacion;
	}

	public String getEditorial() {
		return editorial;
	}

	public void setEditorial(String editorial) {
		this.editorial = editorial;
	}

	@Override
	public String toString() {
		return "Libro [id=" + id + ", titulo=" + titulo + ", precio=" + precio + ", editorial=" + editorial
				+ ", fecha_publicacion=" + fecha_publicacion + "]";
	}

	
	
}
