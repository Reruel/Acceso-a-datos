package conexion.mongo;

import org.bson.Document;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

public class Insertar {
	 public static void main(String[] args) {
	        // Establecer conexión con la base de datos MongoDB
	        try (MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017")) {
	            // Seleccionar la base de datos
	            MongoDatabase database = mongoClient.getDatabase("tienda1");

	            // Obtener una referencia a la colección "fabricante"
	            MongoCollection<Document> collection = database.getCollection("Fabricante");
	            Document newFabricante = new Document().append("nombre", "xiaomi");
	            
	            collection.insertOne(newFabricante);
	            
	            // Realizar una consulta para obtener todos los documentos de la colección
	            try (MongoCursor<Document> cursor = collection.find().iterator()) {
	                // Iterar sobre los documentos y mostrarlos en la consola
	                while (cursor.hasNext()) {
	                    Document document = cursor.next();
	                    System.out.println(document.toJson());
	                }
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
}
