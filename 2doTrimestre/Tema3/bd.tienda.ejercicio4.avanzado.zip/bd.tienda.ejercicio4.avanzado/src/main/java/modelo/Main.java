package modelo;

import java.sql.Date;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.context.internal.ThreadLocalSessionContext;
import org.hibernate.engine.spi.SessionFactoryImplementor;
public class Main {

	public static void main(String[] args) {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		ThreadLocalSessionContext context = new ThreadLocalSessionContext((SessionFactoryImplementor) sessionFactory);
		context.bind(sessionFactory.openSession());
		
		try {
			Fabricante fabricante = new Fabricante("pc gaming97");
			// Obtener la sesión actual
			Session session = context.currentSession();
			session.beginTransaction();
			session.save(fabricante);
			session.getTransaction().commit();

			Producto producto = new Producto("PORTATIL gaming97",3002.00, fabricante);
			Session session1 = context.currentSession();
			session1.beginTransaction();
			session1.save(producto);
			session1.getTransaction().commit();
			
			Compras compra = new Compras(Date.valueOf("2024-01-19"),5,producto);
			
			
			System.out.println(producto.toString());
			System.out.println(fabricante.toString());
			System.out.println(compra.toString());
			
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			// Desligar la sesión del contexto
			ThreadLocalSessionContext.unbind(sessionFactory);
			// Cerrar la sesión de Hibernate
			sessionFactory.close();
			}
		

	}

}
