package modelo;

import java.sql.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.persistence.*;

@Entity
@Table(name = "tvideojuegos")
public class Tvideojuegos {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "nombre")
	private String nombre;

	@Column(name = "anio")
	private int anio;

	@Column(name = "empresa")
	private String empresa;
	
	@Column(name = "precio")
	private float precio;

	@Column(name = "sinopsis")
	private String sinopsis;
	
	@Column(name = "plataforma")
	private String plataforma;

	
	public Tvideojuegos() {
		
	}


	public Tvideojuegos( String nombre, int anio, String empresa, float precio, String sinopsis, String plataforma) {
		super();
		this.nombre = nombre;
		this.anio = anio;
		this.empresa = empresa;
		this.precio = precio;
		this.sinopsis = sinopsis;
		this.plataforma = plataforma;
	}

	

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public int getAnio() {
		return anio;
	}


	public void setAnio(int anio) {
		this.anio = anio;
	}


	public String getempresa() {
		return empresa;
	}


	public void setempresa(String empresa) {
		this.empresa = empresa;
	}


	public float getPrecio() {
		return precio;
	}


	public void setPrecio(int precio) {
		this.precio = precio;
	}


	public String getSinopsis() {
		return sinopsis;
	}


	public void setSinopsis(String sinopsis) {
		this.sinopsis = sinopsis;
	}


	public String getPlataforma() {
		return plataforma;
	}


	public void setPlataforma(String plataforma) {
		this.plataforma = plataforma;
	}


	@Override
	public String toString() {
		return "Tvideojuegos [id=" + id + ", nombre=" + nombre + ", anio=" + anio + ", empresa=" + empresa
				+ ", precio=" + precio + ", sinopsis=" + sinopsis + ", plataforma=" + plataforma + "]";
	}

}