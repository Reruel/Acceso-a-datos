package modelo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table (name="libro_autor")
public class Libro_Autor {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="id")
	private int id;
	
	@ManyToOne
	@JoinColumn(name = "id_libro", nullable = false)
	private Libro libro;
	
	@ManyToOne
	@JoinColumn(name = "id_autor", nullable = false)
	private Autor autor;

	public Libro_Autor() {
		super();
	}

	public Libro_Autor(Libro libro, Autor autor) {
		super();
		this.libro = libro;
		this.autor = autor;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Libro getLibro() {
		return libro;
	}

	public void setLibro(Libro libro) {
		this.libro = libro;
	}

	public Autor getAutor() {
		return autor;
	}

	public void setAutor(Autor autor) {
		this.autor = autor;
	}

	@Override
	public String toString() {
		return "Libro_Autor [id=" + id + ", libro=" + libro + ", autor=" + autor + "]";
	}
	
	
}
