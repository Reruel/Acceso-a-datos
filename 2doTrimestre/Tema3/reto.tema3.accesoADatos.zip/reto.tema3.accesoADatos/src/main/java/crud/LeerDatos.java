package crud;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.context.internal.ThreadLocalSessionContext;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.query.Query;

import modelo.*;

public class LeerDatos {

	public static void main(String[] args) {
		// Configurar la sesión de Hibernate
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

		// Configurar la sesión en el contexto actual
		ThreadLocalSessionContext context = new ThreadLocalSessionContext((SessionFactoryImplementor) sessionFactory);
		context.bind(sessionFactory.openSession());

		try {

			Session session = context.currentSession();
			List<Autor> autores = consultaEntidades(session, Autor.class, "FROM Autor");
			System.out.println("Registros en la tabla autor:");
			imprimirRegistros(autores);

			List<Categoria> categorias = consultaEntidades(session, Categoria.class, "FROM Categoria");
			System.out.println("\nRegistros en la tabla categoria:");
			imprimirRegistros(categorias);
			
			List<Cliente> clientes = consultaEntidades(session, Cliente.class, "FROM Cliente");
			System.out.println("\nRegistros en la tabla Cliente:");
			imprimirRegistros(clientes);
			
			List<Libro> libros = consultaEntidades(session, Libro.class, "FROM Libro");
			System.out.println("\nRegistros en la tabla Libro:");
			imprimirRegistros(libros);
			
			List<Pedido> pedidos = consultaEntidades(session, Pedido.class, "FROM Pedido");
			System.out.println("\nRegistros en la tabla Pedido:");
			imprimirRegistros(pedidos);
			
			List<Libro_Autor> libroAutor = consultaEntidades(session, Libro_Autor.class, "FROM Libro_Autor");
			System.out.println("\nRegistros en la tabla Libro_Autor:");
			imprimirRegistros(libroAutor);
			
			List<Libro_Categoria> libroCategoria = consultaEntidades(session, Libro_Categoria.class, "FROM Libro_Categoria");
			System.out.println("\nRegistros en la tabla Libro_Categoria:");
			imprimirRegistros(libroCategoria);
			
			List<Libro_Pedido> libroPedido = consultaEntidades(session, Libro_Pedido.class, "FROM Libro_Pedido");
			System.out.println("\nRegistros en la tabla Libro_Pedido:");
			imprimirRegistros(libroPedido);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			context.unbind(sessionFactory);
			sessionFactory.close();
		}
	}

	private static <T> List<T> consultaEntidades(Session session, Class<T> entityClass, String hql) {
		session.beginTransaction();
		Query<T> query = session.createQuery(hql, entityClass);
		List<T> resultados = query.list();
		session.getTransaction().commit();
		return resultados;
	}

	private static <T> void imprimirRegistros(List<T> registros) {
		for (T registro : registros) {
			System.out.println(registro.toString());
		}
	}
}
