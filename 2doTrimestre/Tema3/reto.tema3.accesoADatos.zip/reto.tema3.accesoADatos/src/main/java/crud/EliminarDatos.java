package crud;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.context.internal.ThreadLocalSessionContext;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.query.Query;

import modelo.*;

public class EliminarDatos {
	public static void main(String[] args) {

		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

		ThreadLocalSessionContext context = new ThreadLocalSessionContext((SessionFactoryImplementor) sessionFactory);
		context.bind(sessionFactory.openSession());

		try {
			Session session = context.currentSession();
			
			System.out.println("Registros en la tabla autor antes de la eliminación:");
			List<Autor> autores = seleccionarEntidad(session, "FROM Autor WHERE id = 1");
			imprimirRegistros(autores);
			eliminarEntidad(session, "DELETE Autor WHERE id = 1");
			autores = seleccionarEntidad(session, "FROM Autor");
			System.out.println("Registros en la tabla autor después de la actualización:");
			imprimirRegistros(autores);

			System.out.println("Registros en la tabla Categoria antes de la eliminación:");
			List<Categoria> categorias = seleccionarEntidad(session, "FROM Categoria WHERE id = 1");
			imprimirRegistros(categorias);
			eliminarEntidad(session, "DELETE Categoria WHERE id = 1");
			categorias = seleccionarEntidad(session, "FROM Categoria");
			System.out.println("Registros en la tabla Categoria después de la actualización:");
			imprimirRegistros(categorias);
			
			
			System.out.println("Registros en la tabla Cliente antes de la eliminación:");
			List<Cliente> clientes = seleccionarEntidad(session, "FROM Cliente WHERE id = 2");
			imprimirRegistros(clientes);
			eliminarEntidad(session, "DELETE Cliente WHERE id = 2");
			clientes = seleccionarEntidad(session, "FROM Cliente");
			System.out.println("Registros en la tabla Cliente después de la actualización:");
			imprimirRegistros(clientes);
			
			
			System.out.println("Registros en la tabla Libro antes de la eliminación:");
			List<Libro> libros = seleccionarEntidad(session, "FROM Libro WHERE id = 1");
			imprimirRegistros(libros);
			eliminarEntidad(session, "DELETE Libro WHERE id = 1");
			libros = seleccionarEntidad(session, "FROM Libro");
			System.out.println("Registros en la tabla Libro después de la actualización:");
			imprimirRegistros(libros);
			
			
			System.out.println("Registros en la tabla Pedido antes de la eliminación:");
			List<Pedido> pedidos = seleccionarEntidad(session, "FROM Pedido WHERE id = 1");
			imprimirRegistros(pedidos);
			eliminarEntidad(session, "DELETE Pedido WHERE id = 1");
			pedidos = seleccionarEntidad(session, "FROM Pedido");
			System.out.println("Registros en la tabla Pedido después de la actualización:");
			imprimirRegistros(pedidos);
			

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			context.unbind(sessionFactory);
			sessionFactory.close();
		}
	}
	
	private static <T> List<T> seleccionarEntidad(Session session, String selectHql) {
	    session.beginTransaction();
	    Query<T> selectQuery = session.createQuery(selectHql);
	    List<T> resultados = selectQuery.list();
	    session.getTransaction().commit();
	    return resultados;
	}

	private static void eliminarEntidad(Session session, String deleteHql) {
	    session.beginTransaction();
	    Query<?> deleteQuery = session.createQuery(deleteHql);
	    deleteQuery.executeUpdate();
	    session.getTransaction().commit();
	}

	private static <T> void imprimirRegistros(List<T> registros) {
		for (T registro : registros) {
			System.out.println(registro.toString());
		}
	}
}
