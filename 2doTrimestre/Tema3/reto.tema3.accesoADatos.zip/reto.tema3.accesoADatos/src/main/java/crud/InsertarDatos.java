package crud;

import java.sql.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.context.internal.ThreadLocalSessionContext;
import org.hibernate.engine.spi.SessionFactoryImplementor;

import modelo.*;

public class InsertarDatos {

	public static void main(String[] args) {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		ThreadLocalSessionContext context = new ThreadLocalSessionContext((SessionFactoryImplementor) sessionFactory);
		context.bind(sessionFactory.openSession());
		
		try {
			Autor autor = new Autor("Juani 2","Quintero",20);
			// Obtener la sesión actual
			Session session = context.currentSession();
			session.beginTransaction();
			session.save(autor);
			session.getTransaction().commit();
			System.out.println(autor.toString());
			
			Cliente cliente = new Cliente("AlbertoCD","Ruíz",40,"Málaga","AAA111111");
			Session session2 = context.currentSession();
			session2.beginTransaction();
			session2.save(cliente);
			session2.getTransaction().commit();
			System.out.println(cliente.toString());
			
			
			Categoria categoria = new Categoria("Terror");
			Session session3 = context.currentSession();
			session3.beginTransaction();
			session3.save(categoria);
			session3.getTransaction().commit();
			System.out.println(categoria.toString());
			
			Libro libro = new Libro("Harry Potter y la cámara secreta 2", 25.50,"Salamandra", Date.valueOf("1998-07-02"));
			Session session4 = context.currentSession();
			session4.beginTransaction();
			session4.save(libro);
			session4.getTransaction().commit();
			System.out.println(libro.toString()); 
			
			Pedido pedido = new Pedido(Date.valueOf("2024-01-20"),cliente);
			Session session5 = context.currentSession();
			session5.beginTransaction();
			session5.save(pedido);
			session5.getTransaction().commit();
			System.out.println(pedido.toString());
			
			Libro_Autor libroAutor = new Libro_Autor(libro,autor);
			Session session6 = context.currentSession();
			session6.beginTransaction();
			session6.save(libroAutor);
			session6.getTransaction().commit();
			System.out.println(libroAutor.toString()); 
			
			
			Libro_Categoria libroCategoria = new Libro_Categoria(libro,categoria);
			Session session7 = context.currentSession();
			session7.beginTransaction();
			session7.save(libroCategoria);
			session7.getTransaction().commit();
			System.out.println(libroCategoria.toString());
			
			
			Libro_Pedido libroPedido = new Libro_Pedido(libro,pedido);
			Session session8 = context.currentSession();
			session8.beginTransaction();
			session8.save(libroPedido);
			session8.getTransaction().commit();
			System.out.println(libroPedido.toString()); 
			
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			// Desligar la sesión del contexto
			ThreadLocalSessionContext.unbind(sessionFactory);
			// Cerrar la sesión de Hibernate
			sessionFactory.close();
			}

	}

}
