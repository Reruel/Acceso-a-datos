package crud;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.context.internal.ThreadLocalSessionContext;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.hibernate.query.Query;

import modelo.*;

public class ActualizarDatos {
	public static void main(String[] args) {
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

		ThreadLocalSessionContext context = new ThreadLocalSessionContext((SessionFactoryImplementor) sessionFactory);
		context.bind(sessionFactory.openSession());

		try {
			Session session = context.currentSession();

			actualizarEntidad(session, "UPDATE Autor SET nombre = 'Gandalf' WHERE id = 4");
			List<Autor> autores = seleccionarEntidad(session, "FROM Autor WHERE id = 4");
			System.out.println("Registros en la tabla autor después de la actualización:");
			imprimirRegistros(autores);
			
			actualizarEntidad(session, "UPDATE Categoria SET nombre = 'Acción' WHERE id = 2");
			List<Categoria> categorias = seleccionarEntidad(session, "FROM Categoria WHERE id = 2");
			System.out.println("\nRegistros en la tabla categoria después de la actualización:");
			imprimirRegistros(categorias);

			actualizarEntidad(session, "UPDATE Cliente SET apellidos = 'Simpson' WHERE id = 3");
			List<Cliente> clientes = seleccionarEntidad(session, "FROM Cliente WHERE id = 3");
			System.out.println("\nRegistros en la tabla cliente después de la actualización:");
			imprimirRegistros(clientes);
			
			actualizarEntidad(session, "UPDATE Libro SET precio = 35.89 WHERE id = 2");
			List<Libro> libros = seleccionarEntidad(session, "FROM Libro WHERE id = 2");
			System.out.println("\nRegistros en la tabla libro después de la actualización:");
			imprimirRegistros(libros);
			
			actualizarEntidad(session, "UPDATE Pedido SET fecha = '2003-12-10' WHERE id = 2");
			List<Pedido> pedidos = seleccionarEntidad(session, "FROM Pedido WHERE id = 2");
			System.out.println("\nRegistros en la tabla pedido después de la actualización:");
			imprimirRegistros(pedidos);
			
			actualizarEntidad(session, "UPDATE Libro_Pedido SET id_libro = 4 WHERE id = 2");
			List<Libro_Pedido> libros_pedidos = seleccionarEntidad(session, "FROM Libro_Pedido WHERE id = 2");
			System.out.println("\nRegistros en la tabla libros_pedidos después de la actualización:");
			imprimirRegistros(libros_pedidos);
			
			actualizarEntidad(session, "UPDATE Libro_Categoria SET id_categoria = 1 WHERE id = 4");
			List<Libro_Categoria> libros_categorias = seleccionarEntidad(session, "FROM Libro_Categoria WHERE id = 4");
			System.out.println("\nRegistros en la tabla libros_categorias después de la actualización:");
			imprimirRegistros(libros_categorias);
			
			actualizarEntidad(session, "UPDATE Libro_Autor SET id_autor = 5 WHERE id = 1");
			List<Libro_Autor> libros_autores = seleccionarEntidad(session, "FROM Libro_Autor WHERE id = 1");
			System.out.println("\nRegistros en la tabla Libro_Autor después de la actualización:");
			imprimirRegistros(libros_autores);
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			context.unbind(sessionFactory);
			sessionFactory.close();
		}
	}

	private static void actualizarEntidad(Session session, String updateHql) {
		session.beginTransaction();
		Query<?> updateQuery = session.createQuery(updateHql);
		updateQuery.executeUpdate();
	}

	private static <T> List<T> seleccionarEntidad(Session session, String selectHql) {
		Query<T> selectQuery = session.createQuery(selectHql);
		session.getTransaction().commit();
		return selectQuery.list();
	}

	private static <T> void imprimirRegistros(List<T> registros) {
		for (T registro : registros) {
			System.out.println(registro.toString());
		}
	}
}
