package modelo;

import java.sql.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.context.internal.ThreadLocalSessionContext;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Main {

	public static void main(String[] args) {
		SessionFactory sessionFactory = new Configuration().configure()

				.buildSessionFactory();

		ThreadLocalSessionContext context = new ThreadLocalSessionContext((SessionFactoryImplementor) sessionFactory);
		context.bind(sessionFactory.openSession());

		try {

			Alumno alumno = new Alumno("Reyes", "Rubio", "Elena", Date.valueOf("1992-03-28"), "no",
					"622731351");

			Session session = context.currentSession();

			session.beginTransaction();

			session.save(alumno);

			session.getTransaction().commit();

			System.out.println("Alumno: " + alumno);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			ThreadLocalSessionContext.unbind(sessionFactory);

			sessionFactory.close();
		}
	}
}
