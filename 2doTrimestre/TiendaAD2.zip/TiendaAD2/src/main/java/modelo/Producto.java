package modelo;

import java.sql.Date;
import javax.persistence.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Entity
@Table (name="producto")
public class Producto {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "nombre")
	private String nombre;
	
	
	@Column(name = "precio")
	private float precio;

	
	@ManyToOne
	@JoinColumn(name = "codigo_fabricante", nullable = false)
	private Fabricante fabricante;
	
	//Constructor por defecto requerido por Hibernate
	public Producto() {
		
	}
	
	//Constructor para crear un objeto de tipo Clientes con un nombre y una ciudad

	public Producto(String nombre, float precio, Fabricante fabricante) {
		super();
		this.nombre = nombre;
		this.precio = precio;
		this.fabricante = fabricante;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	
	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public Fabricante getFabricante() {
		return fabricante;
	}

	public void setFabricante(Fabricante fabricante) {
		this.fabricante = fabricante;
	}

	

	@Override
	public String toString() {
		return "Producto [id=" + id + ", nombre=" + nombre + " precio=" + precio
				+ ", fabricante=" + fabricante  + "]";
	}
}
	